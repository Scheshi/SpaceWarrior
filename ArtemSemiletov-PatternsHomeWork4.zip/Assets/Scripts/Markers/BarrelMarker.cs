﻿using UnityEngine;


namespace Asteroids
{
    public class BarrelMarker : MonoBehaviour
    {
    }
}
