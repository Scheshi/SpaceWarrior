﻿namespace Asteroids.Interfaces
{
    interface IUpdatable
    {
    }
}
