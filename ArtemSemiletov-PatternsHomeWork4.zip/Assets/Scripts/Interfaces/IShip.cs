﻿namespace Asteroids.Interfaces
{
    internal interface IShip : IMove, IRotation
    {
    }
}
