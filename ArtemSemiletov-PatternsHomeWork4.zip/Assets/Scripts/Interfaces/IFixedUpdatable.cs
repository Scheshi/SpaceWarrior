﻿using System;


namespace Asteroids.Interfaces
{
    interface IFixedUpdatable : IUpdatable
    {
        void FixedUpdate();
    }
}
