﻿namespace Asteroids.Interfaces
{
    interface IPlayer : IDamagable
    {
        
    }
}
