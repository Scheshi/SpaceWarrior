﻿namespace Asteroids.Interfaces
{
    interface IWeapon
    {
        void Fire();
    }
}
