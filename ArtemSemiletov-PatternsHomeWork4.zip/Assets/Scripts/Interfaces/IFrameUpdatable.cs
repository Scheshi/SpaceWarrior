﻿namespace Asteroids.Interfaces
{
    internal interface IFrameUpdatable : IUpdatable
    {
        void Update();
    }
}